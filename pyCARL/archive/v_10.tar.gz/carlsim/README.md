GPU-accelerated spiking neural network simulator. CARLsim's swig-python bindings (i.e. pyCARL).
